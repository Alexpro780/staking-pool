# staking-pool

A minimal template for a pooled staking contract where users deposit ETH and track their share of the pool.

## Features
- Simple staking and unstaking logic
- Tracks user balances and total pool size
- Ready to extend with real yield integrations

## Tech Stack
- Solidity
- Hardhat
- Node.js
